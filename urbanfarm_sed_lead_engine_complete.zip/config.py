LINKEDIN_EMAIL = "henlo@urbanfarmafrica.com"

MESSAGE_TEMPLATE = """
Hi {name},

My name is Henlo Pulzone from UrbanFarm Africa.

We help corporates execute high-impact Social Economic Development (SED)
and Enterprise Development agricultural projects that strengthen BEE
scorecards while building sustainable food security systems.

I would love to explore whether your organisation is planning any SED
or Enterprise Development initiatives.

Kind regards
Henlo Pulzone
UrbanFarm Africa
"""
