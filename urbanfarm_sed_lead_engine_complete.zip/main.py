from modules.scraper import load_companies
from modules.lead_filter import generate_leads
from modules.crm import save_lead

def run():

    companies = load_companies()

    total = 0

    for i,row in companies.iterrows():

        company = row["company"]

        leads = generate_leads(company)

        for lead in leads:

            save_lead(lead)

            print("Lead created:",lead)

            total += 1

    print("Total leads generated:", total)

if __name__ == "__main__":
    run()
