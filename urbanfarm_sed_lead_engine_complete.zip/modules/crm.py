import pandas as pd
import os

LEAD_FILE = "data/leads.csv"

def save_lead(lead):

    if os.path.exists(LEAD_FILE):
        df = pd.read_csv(LEAD_FILE)
    else:
        df = pd.DataFrame(columns=["company","role","status","linkedin"])

    new_row = {
        "company": lead["company"],
        "role": lead["role"],
        "status": "UNREAD",
        "linkedin": lead["linkedin_search"]
    }

    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    df.to_csv(LEAD_FILE, index=False)
