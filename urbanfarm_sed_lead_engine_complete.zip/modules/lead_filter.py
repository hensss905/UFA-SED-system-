roles = [
"Head of Sustainability",
"ESG Manager",
"CSR Manager",
"Enterprise Development Manager",
"Social Impact Manager",
"BEE Manager"
]

def generate_leads(company):

    leads = []

    for role in roles:
        leads.append({
            "company": company,
            "role": role,
            "linkedin_search": f"https://www.linkedin.com/search/results/people/?keywords={company}%20{role}"
        })

    return leads
