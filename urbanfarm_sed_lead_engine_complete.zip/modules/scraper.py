import pandas as pd

def load_companies():
    df = pd.read_csv("companies.csv")
    return df
