from config import MESSAGE_TEMPLATE

def generate_message(name, company):
    return MESSAGE_TEMPLATE.format(name=name, company=company)
